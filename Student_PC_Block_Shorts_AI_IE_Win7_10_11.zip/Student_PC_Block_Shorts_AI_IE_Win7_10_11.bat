@echo off
setlocal EnableExtensions
 title Afrimat College - Block Shorts and AI Tools

:: Require Administrator privileges
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo.
  echo ERROR: Please right-click this file and choose "Run as administrator".
  echo.
  pause
  exit /b 1
)

set "HOSTS=%SystemRoot%\System32\drivers\etc\hosts"
set "MARKER=# AFRIMAT_STUDENT_AI_BLOCK"

if not exist "%HOSTS%" (
  echo ERROR: Could not find the Windows HOSTS file: %HOSTS%
  pause
  exit /b 1
)

:: Add browser URL block policies for Chrome and Edge.
:: Numbered entries are used by the supported Chrome/Edge URLBlocklist policy.
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\URLBlocklist" /v 1 /t REG_SZ /d "youtube.com/shorts" /f >nul
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\URLBlocklist" /v 2 /t REG_SZ /d "bing.com/chat" /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist" /v 1 /t REG_SZ /d "youtube.com/shorts" /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist" /v 2 /t REG_SZ /d "bing.com/chat" /f >nul

:: Internet Explorer has no equivalent Chrome/Edge URLBlocklist policy.
:: Use HOSTS entries for AI hostnames so the block also applies to IE.
findstr /i /c:"%MARKER%" "%HOSTS%" >nul 2>&1
if errorlevel 1 (
  if not exist "%HOSTS%.afrimatai.bak" copy /y "%HOSTS%" "%HOSTS%.afrimatai.bak" >nul
  echo.>>"%HOSTS%"
  echo # AI domains blocked by Afrimat College student lab script>>"%HOSTS%"

  call :addhost chatgpt.com
  call :addhost www.chatgpt.com
  call :addhost openai.com
  call :addhost www.openai.com
  call :addhost platform.openai.com
  call :addhost auth.openai.com
  call :addhost api.openai.com
  call :addhost oaistatic.com
  call :addhost oaiusercontent.com
  call :addhost claude.ai
  call :addhost www.claude.ai
  call :addhost anthropic.com
  call :addhost www.anthropic.com
  call :addhost gemini.google.com
  call :addhost aistudio.google.com
  call :addhost notebooklm.google.com
  call :addhost generativelanguage.googleapis.com
  call :addhost copilot.microsoft.com
  call :addhost copilot.com
  call :addhost perplexity.ai
  call :addhost www.perplexity.ai
  call :addhost pplx.ai
  call :addhost deepseek.com
  call :addhost www.deepseek.com
  call :addhost chat.deepseek.com
  call :addhost grok.com
  call :addhost www.grok.com
  call :addhost x.ai
  call :addhost www.x.ai
  call :addhost poe.com
  call :addhost www.poe.com
  call :addhost character.ai
  call :addhost www.character.ai
  call :addhost meta.ai
  call :addhost www.meta.ai
  call :addhost mistral.ai
  call :addhost www.mistral.ai
  call :addhost you.com
  call :addhost www.you.com
  call :addhost huggingface.co
  call :addhost huggingchat.com
  call :addhost phind.com
  call :addhost www.phind.com
  call :addhost blackbox.ai
  call :addhost www.blackbox.ai
  call :addhost jasper.ai
  call :addhost www.jasper.ai
  call :addhost writesonic.com
  call :addhost www.writesonic.com
  call :addhost copy.ai
  call :addhost www.copy.ai
  call :addhost gamma.app
  call :addhost www.gamma.app
  call :addhost midjourney.com
  call :addhost www.midjourney.com
  call :addhost leonardo.ai
  call :addhost www.leonardo.ai
  call :addhost ideogram.ai
  call :addhost www.ideogram.ai
  call :addhost runwayml.com
  call :addhost www.runwayml.com
  call :addhost elevenlabs.io
  call :addhost www.elevenlabs.io
  call :addhost suno.com
  call :addhost www.suno.com
  call :addhost udio.com
  call :addhost www.udio.com
  call :addhost stability.ai
  call :addhost www.stability.ai
) else (
  echo HOSTS file already contains this script's AI block entries; not adding duplicates.
)

ipconfig /flushdns >nul

echo.
echo SUCCESS: Browser restrictions have been applied where supported.
echo - Chrome and Edge: YouTube Shorts URL and Bing Chat URL policies added.
echo - Internet Explorer and all browsers: listed AI hostnames blocked through HOSTS.
echo - Your MikroTik DNS rules should continue blocking AI domains and subdomains.
echo.
echo IMPORTANT: Internet Explorer cannot reliably block only the /shorts path
 echo while keeping other YouTube videos available. The Shorts path rule is for
 echo supported Chrome and Edge versions only.
echo.
echo Close and reopen your browsers. Check chrome://policy and edge://policy.
echo.
pause
exit /b 0

:addhost
>>"%HOSTS%" echo 0.0.0.0 %~1 %MARKER%
>>"%HOSTS%" echo :: %~1 %MARKER%
exit /b 0
